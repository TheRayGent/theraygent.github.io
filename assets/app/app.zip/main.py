# #import flet as ft
# from flet import Page, ElevatedButton, MainAxisAlignment, CrossAxisAlignment, ControlEvent, animation, AnimationCurve, app, Colors, HapticFeedback, ButtonStyle, TextStyle, Offset, Container, StadiumBorder, Row, Stack, WindowResizeEvent
# from mybutton import *

# async def main(page: Page):
#     page.theme_mode = "light"
#     page.title = 'App'
#     #page.window.min_width = 650+16
#     #page.window.min_height = 366
#     page.adaptive = True
#     page.vertical_alignment = MainAxisAlignment.CENTER
#     page.horizontal_alignment = CrossAxisAlignment.CENTER

#     async def on_hover(e: ControlEvent):
#         control: ElevatedButton = e.control
#         #control.scale = 1.1 if e.data == "true" else 1
#         control.update()

#     button = ElevatedButton(
#         "Button",
#         width = 90, 
#         height = 40, 
#         on_hover=on_hover,
#         animate_scale = animation.Animation(300, AnimationCurve.EASE_IN_OUT),
#         style=ButtonStyle(
#             text_style=TextStyle(16),
#             shadow_color=Colors.BLACK87,
#             elevation={"pressed": 0, "": 4},
#             shape=StadiumBorder()

#             ))


#     hf = HapticFeedback()
#     page.overlay.append(hf)
    
#     async def on_tap_click(e: ControlEvent):
        
#         e.control.offset = Offset(0,0)
#         hf.light_impact()
#         e.control.update()

#     async def on_click(e: ControlEvent):
#         e.control.offset = offset=Offset(0.05,-0.1)
#         e.control.update()

#     button1 = MyButton("MyButton", width=90, height=40, on_hover=on_hover, elevation={"pressed": 0, "hovered": 3,"": 1}, on_click=on_click, offset=Offset(0.05,-0.1), animate_offset=animation.Animation(100, AnimationCurve.EASE_IN_OUT))



#     stack = Stack(controls=[Container(bgcolor=Colors.GREY, width=button1.width, height=button1.height, border_radius=50), Container(bgcolor=Colors.GREY_400, width=button1.width, height=button1.height, border_radius=50, offset=Offset(0.05,-0.1), on_tap_down=on_tap_click, on_click=on_click, animate_offset=animation.Animation(100, AnimationCurve.EASE_IN_OUT))])
#     print(1)

#     async def on_resized(e: WindowResizeEvent):
#         #print((page.width/button.width/2), " ", page.height/button.height/2)
#         row.scale = (page.width/button.width/3)
#         #button.scale = (page.width/button.width/2)# if page.width<=page.height else page.height/button.height/2)
#         #button.width, button.height = (button_size()/1.5, button_size()/4)
#         #button.style.text_style = TextStyle(1.5*(page.width/button.width/2))
#         row.update()


#     page.on_resized = on_resized

#     button3 = ElevatedButton("Button3", width=90, height=40)

#     row = Row([button3, stack], alignment=MainAxisAlignment.CENTER, animate_scale = animation.Animation(350, AnimationCurve.EASE_IN_OUT), spacing=10)
#     row.scale = (page.width/button.width/3)
#     page.add(row)

#     page.update()
    
# app(target=main)

from flet import (
    Page,
    ElevatedButton,
    MainAxisAlignment,
    CrossAxisAlignment,
    ControlEvent,
    animation,
    AnimationCurve,
    app,
    Colors,
    HapticFeedback,
    ButtonStyle,
    TextStyle,
    Offset,
    Container,
    StadiumBorder,
    Row,
    Stack,
    WindowResizeEvent,
)
# Assuming MyButton is a well-defined and reusable component
from mybutton import MyButton  # Keep this if you have a custom button


async def main(page: Page):
    page.title = 'App'
    page.theme_mode = "light"  # Consider using page.theme = Theme(...) for more control
    page.vertical_alignment = MainAxisAlignment.CENTER
    page.horizontal_alignment = CrossAxisAlignment.CENTER
    #Adaptive can be set on individual elements as well, instead of globally, if needed
    #page.adaptive = True 

    # --- Reusable Hover Effect ---
    async def on_hover(e: ControlEvent):
        """Simple hover effect."""
        control: ElevatedButton = e.control
        control.scale = 1.1 if e.data == "true" else 1
        await control.update_async() #Use async update for better performance

    # --- Button Styles ---
    button_style = ButtonStyle(
        text_style=TextStyle(16),
        shadow_color=Colors.BLACK87,
        elevation={
            "pressed": 0,
            "": 4
        },  # Use a dictionary for different states
        shape=StadiumBorder()  # Consistent shape
    )

    # --- Haptic Feedback ---
    hf = HapticFeedback()
    page.overlay.append(hf) #Append once
    async def on_tap_click(e: ControlEvent):
        """Haptic feedback on tap."""
        hf.light_impact()
        await page.update_async()

    async def on_click(e: ControlEvent):
        """Button click animation."""
        control: Container = e.control
        control.offset = Offset(0.05, -0.1)
        (await control.update_async())

    # --- Button Declarations ---
    button = ElevatedButton(
        "Button",
        width=90,
        height=40,
        on_hover=on_hover,
        style=button_style,
        animate_scale=animation.Animation(300, AnimationCurve.EASE_IN_OUT)
    )

    button1 = MyButton(
        "MyButton",
        width=90,
        height=40,
        on_hover=on_hover,
        elevation={
            "pressed": 0,
            "hovered": 3,
            "": 1
        },  # Consistent elevation dictionary
        on_click=on_click,
        offset=Offset(0.05, -0.1),
        animate_offset=animation.Animation(100, AnimationCurve.EASE_IN_OUT)
    )

    # --- Stacked Button ---
    # Replaced the direct stack with a UserControl.
    class StackedButton(Stack):
        def __init__(self,width,height,on_tap_down,on_click):
            super().__init__()
            self.width=width
            self.height=height
            self.on_tap_down = on_tap_down
            self.on_click = on_click
        def build(self):
            return Stack(
                controls=[
                    Container(
                        bgcolor=Colors.GREY,
                        width=self.width,
                        height=self.height,
                        border_radius=50
                    ),
                    Container(
                        bgcolor=Colors.GREY_400,
                        width=self.width,
                        height=self.height,
                        border_radius=50,
                        offset=Offset(0.05, -0.1),
                        on_tap_down=self.on_tap_down,
                        on_click=self.on_click,
                        animate_offset=animation.Animation(100, AnimationCurve.EASE_IN_OUT)
                    )
                ]
            )
    stack = StackedButton(width = button1.width,height=button1.height, on_tap_down = on_tap_click, on_click = on_click)

    # --- Responsive Scaling ---
    async def on_resized(e: WindowResizeEvent):
        """Scales the row based on window size."""
        new_scale = page.width / button.width / 3
        row.scale = new_scale
        await row.update_async() #Use async


    page.on_resized = on_resized

    # --- Row Layout ---
    button3 = ElevatedButton("Button3", width=90, height=40)  # Consistent sizes

    row = Row(
        [button3, stack],
        alignment=MainAxisAlignment.CENTER,
        animate_scale=animation.Animation(350, AnimationCurve.EASE_IN_OUT),
        spacing=10,
    )
    row.scale = (page.width / button.width / 3)  # Initial scale
    page.add(row)

    await page.update_async() #Await the update for efficiency

app(target=main)